# CDM.ug 🇺🇬

A mobile-friendly adventure/touring website for CDM.ug.

## Publish free with GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new **public** repository named `YOURUSERNAME.github.io`.
3. Upload `index.html`.
4. Open repository **Settings → Pages**.
5. Under Source choose **Deploy from a branch**, select `main`, folder `/root`, then Save.
6. Your site will appear at `https://YOURUSERNAME.github.io/`.

## Before publishing
Replace the placeholder social links and add your real WhatsApp number inside `index.html` where the booking script says to add it.
